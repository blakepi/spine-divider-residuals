# Nature Neuroscience Final Submission QA Report

Date: 2026-06-12

- Build status: see `submission/final/FINAL_SUBMISSION_QA_REPORT.md` for command results.
- Abstract word count: 139.
- Main text word count: 2471.
- Display items: 8 (7 figures, 1 table).
- Required statements: present.
- Author metadata: present and unblinded.
- Corresponding author: Alberto Musto, MD, PhD, `mustoae@odu.edu`.
- Gregory Pierpoint is not listed as MD.
- Gregory ORCID: locked as `https://orcid.org/0000-0001-8288-8549`.
- Shared affiliation: departments consolidated under one institutional affiliation.
- Cover letter: Alberto E. Musto, MD, PhD appears above Gregory Blake Pierpoint in the closing block.
- Figure 1: replaced with the user-supplied publication PNG and PDF wrapper; no figure data values changed.
- Supplement layout: supplementary figure inclusions widened to 0.98 text width for readability.
- NEURON validation: not claimed.
- Deterministic uncertainty: design-fraction language retained.
- Zenodo version DOI: https://doi.org/10.5281/zenodo.20672333
- Zenodo concept DOI: https://doi.org/10.5281/zenodo.20672356
- Final human-review QA: see `submission/final_human_review_revision/FINAL_HUMAN_REVIEW_REVISION_REPORT.md`.
